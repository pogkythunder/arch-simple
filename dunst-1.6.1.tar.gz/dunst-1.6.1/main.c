#include "src/dunst.h"

int main(int argc, char *argv[])
{
        return dunst_main(argc, argv);
}
/* vim: set ft=c tabstop=8 shiftwidth=8 expandtab textwidth=0: */

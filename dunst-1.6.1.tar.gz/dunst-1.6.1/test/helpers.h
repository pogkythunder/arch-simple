#ifndef DUNST_TEST_HELPERS_H
#define DUNST_TEST_HELPERS_H

#include <glib.h>

GVariant *notification_setup_raw_image(const char *path);

#endif
/* vim: set tabstop=8 shiftwidth=8 expandtab textwidth=0: */

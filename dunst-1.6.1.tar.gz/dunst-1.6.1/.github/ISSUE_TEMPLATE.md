<!--

If you want to report bugs, it's the best to get something reproducible!

These program calls might help:

While the notification gets sent:
`dbus-monitor path=/org/freedesktop/Notifications`

If dunst segfaults (please install the debug symbols or install dunst manually again):
`gdb -ex run dunst -ex bt`

* ISSUE DESCRIPTION GOES BELOW THIS LINE * -->




### Installation info

<!-- If your version dates before 1.2, please rule out, that the behavior is fixed in master already -->

- Version: `<!-- output of dunst -v -->`
- Install type: `<!-- [package|manually|...] -->`
- Distro and version: ` `

# that's so fetch
*insert picture of mean girls*

Simple fetch program written in C.

## Dependencies
* clang/gcc
* C
* make

## Compilation
```
make all
./tsfetch
```

## Supported OS
Probably most linux...
Maybe BSD...


